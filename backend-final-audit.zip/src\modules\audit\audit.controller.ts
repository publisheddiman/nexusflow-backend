import type { Context } from "hono";
import type { CurrentUserContext } from "../../middleware/current-user.middleware";
import { auditService } from "./audit.service";

export class AuditController {
  async getTaskLogs(c: Context<CurrentUserContext>) {
    try {
      const user = c.get("user");
      const taskId = c.req.param("taskId");

      if (!taskId) {
        return c.json(
          {
            message: "Task ID is required",
          },
          400,
        );
      }

      if (user.role !== "PM") {
        return c.json(
          {
            message: "Only PM can view audit logs",
          },
          403,
        );
      }

      const logs = await auditService.getTaskLogs(taskId);

      return c.json({
        message: "Audit logs retrieved successfully",
        data: logs,
      });
    } catch {
      return c.json(
        {
          message: "Failed to retrieve audit logs",
        },
        500,
      );
    }
  }
}

export const auditController = new AuditController();
