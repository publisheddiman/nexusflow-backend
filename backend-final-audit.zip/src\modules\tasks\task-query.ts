import {
  BuildQueryFilter,
  extractQueryFromParams,
  type FilteringQuery,
  type QueryParams,
} from "@nodewave/prisma-ezfilter";

export type TaskListQueryParams = QueryParams;

const TASK_ALLOWED_FIELDS = [
  "id",
  "projectId",
  "title",
  "description",
  "status",
  "department",
  "assigneeId",
  "createdById",
  "isClientVisible",
  "createdAt",
  "updatedAt",
] as const;

const taskQueryBuilder = new BuildQueryFilter({
  allowedFields: [...TASK_ALLOWED_FIELDS],
  maxPageSize: 100,
  defaultPageSize: 10,
  defaultSearchMode: "insensitive",
  forbiddenFields: ["deletedAt"],
});

export function buildTaskListQuery(params: TaskListQueryParams) {
  let filteringQuery: FilteringQuery;

  try {
    filteringQuery = extractQueryFromParams(params);
  } catch {
    throw new Error("Invalid task query parameters");
  }

  const result = taskQueryBuilder.build(filteringQuery);

  if (!result.validation.isValid) {
    throw new Error(
      result.validation.errors[0] ?? "Invalid task query parameters",
    );
  }

  return {
    where: result.query.where,
    orderBy: result.query.orderBy ?? {
      createdAt: "desc" as const,
    },
    take: result.query.take,
    skip: result.query.skip,
    page: filteringQuery.page ?? 1,
    rows: filteringQuery.rows ?? 10,
  };
}
