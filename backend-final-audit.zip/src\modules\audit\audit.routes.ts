import { Hono } from "hono";
import { auditController } from "./audit.controller";
import {
  currentUserMiddleware,
  type CurrentUserContext,
} from "../../middleware/current-user.middleware";

const auditRoutes = new Hono<CurrentUserContext>();

auditRoutes.use("*", currentUserMiddleware);

auditRoutes.get("/tasks/:taskId", (c) => auditController.getTaskLogs(c));

export default auditRoutes;
