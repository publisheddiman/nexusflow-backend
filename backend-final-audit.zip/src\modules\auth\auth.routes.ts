import { Hono } from "hono";
import {
  currentUserMiddleware,
  type CurrentUserContext,
} from "../../middleware/current-user.middleware";
import { authController } from "./auth.controller";

const authRoutes = new Hono<CurrentUserContext>();

authRoutes.post("/register", (c) => authController.register(c));

authRoutes.post("/login", (c) => authController.login(c));

authRoutes.get("/me", currentUserMiddleware, (c) => {
  const user = c.get("user");

  return c.json({
    message: "Authenticated user",
    data: user,
  });
});

authRoutes.post("/logout", currentUserMiddleware, (c) =>
  authController.logout(c),
);

export default authRoutes;
