﻿import {
  BuildQueryFilter,
  extractQueryFromParams,
  type FilteringQuery,
  type QueryParams,
} from "@nodewave/prisma-ezfilter";

export type ProjectListQueryParams = QueryParams;

const PROJECT_ALLOWED_FIELDS = [
  "id",
  "name",
  "description",
  "clientId",
  "createdAt",
  "updatedAt",
] as const;

const projectQueryBuilder = new BuildQueryFilter({
  allowedFields: [...PROJECT_ALLOWED_FIELDS],
  maxPageSize: 100,
  defaultPageSize: 10,
  defaultSearchMode: "insensitive",
  forbiddenFields: ["deletedAt"],
});

export function buildProjectListQuery(
  params: ProjectListQueryParams,
) {
  let filteringQuery: FilteringQuery;

  try {
    filteringQuery = extractQueryFromParams(params);
  } catch {
    throw new Error("Invalid project query parameters");
  }

  const result = projectQueryBuilder.build(filteringQuery);

  if (!result.validation.isValid) {
    throw new Error(
      result.validation.errors[0] ??
        "Invalid project query parameters",
    );
  }

  return {
    where: result.query.where,
    orderBy:
      result.query.orderBy ?? {
        createdAt: "desc" as const,
      },
    take: result.query.take,
    skip: result.query.skip,
    page: filteringQuery.page ?? 1,
    rows: filteringQuery.rows ?? 10,
  };
}
