import { prisma } from "../../lib/prisma";

type CreateAuditInput = {
  taskId: string;
  userId: string;
  changedColumn: string;
  oldValue: string | null;
  newValue: string | null;
};

export class AuditService {
  async createLog(input: CreateAuditInput) {
    return prisma.auditLog.create({
      data: {
        taskId: input.taskId,
        userId: input.userId,
        changedColumn: input.changedColumn,
        oldValue: input.oldValue,
        newValue: input.newValue,
      },
    });
  }

  async getTaskLogs(taskId: string) {
    return prisma.auditLog.findMany({
      where: {
        taskId,
      },
      orderBy: {
        createdAt: "asc",
      },
    });
  }
}

export const auditService = new AuditService();
