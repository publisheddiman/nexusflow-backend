import type { Context } from "hono";
import type { CurrentUserContext } from "../../middleware/current-user.middleware";
import { authService } from "./auth.service";
import { loginSchema, registerSchema } from "./auth.schema";

export class AuthController {
  async register(c: Context) {
    try {
      const body = await c.req.json();

      const result = registerSchema.safeParse(body);

      if (!result.success) {
        return c.json(
          {
            message: "Validation failed",
            errors: result.error.flatten(),
          },
          400,
        );
      }

      const { name, email, password } = result.data;

      const user = await authService.register(name, email, password);

      return c.json(
        {
          message: "Registration successful",
          data: user,
        },
        201,
      );
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Registration failed";

      if (message === "Email already registered") {
        return c.json(
          {
            message,
          },
          409,
        );
      }

      return c.json(
        {
          message: "Registration failed",
        },
        500,
      );
    }
  }

  async login(c: Context) {
    try {
      const body = await c.req.json();

      const result = loginSchema.safeParse(body);

      if (!result.success) {
        return c.json(
          {
            message: "Validation failed",
            errors: result.error.flatten(),
          },
          400,
        );
      }

      const { email, password } = result.data;

      const resultLogin = await authService.login(email, password);

      return c.json({
        message: "Login successful",
        data: resultLogin,
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Login failed";

      if (message === "Invalid email or password") {
        return c.json(
          {
            message,
          },
          401,
        );
      }

      return c.json(
        {
          message: "Login failed",
        },
        500,
      );
    }
  }

  async logout(c: Context<CurrentUserContext>) {
    try {
      const user = c.get("user");
      const sessionId = c.get("sessionId");

      await authService.logout(user.id, sessionId);

      return c.json({
        message: "Logout successful",
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Logout failed";

      if (message === "Session not found or already revoked") {
        return c.json(
          {
            message,
          },
          401,
        );
      }

      return c.json(
        {
          message: "Logout failed",
        },
        500,
      );
    }
  }
}

export const authController = new AuthController();
